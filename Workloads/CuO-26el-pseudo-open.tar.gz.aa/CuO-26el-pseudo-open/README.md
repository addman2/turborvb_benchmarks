# Description

System: CuO Dimer
Type: Open
Electrons: 26
Pseudo: Yes

Execute:

‘‘‘
export EXE=turborvb-serial.x

cd energy

$EXE < datasvmc.input > datasvmc.output
$EXE < datasfn.input > datasfn.output
$EXE < datasfnc.input > datasfnc.output
‘‘‘

Another possibility is to run ‘run‘ script. Before one has to setup few enviromental variables.

‘‘‘
export EXE=<path-to-the-executable> # Mandatory
export MPI_PREFIX="mpirun -np 65536" # Needed for mpirun tests
export NW=512 # Number of walkers (not necessary, default is 1
export OMP_NUM_THREADS=16

./run
‘‘‘

To clean everything run ‘clean‘ script.
